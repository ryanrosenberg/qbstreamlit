import re
import streamlit as st

def local_css(file_name):
    st.markdown('<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inconsolata&display=swap" rel="stylesheet">', unsafe_allow_html=True)
    st.markdown('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />', unsafe_allow_html=True)
    with open(file_name) as f:
        st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)

def sanitize_answer(answer):
    answer = re.sub(r'\<b\>', '', answer)
    answer = re.sub(r'\<i\>', '', answer)
    answer = re.sub(r'\</b\>', '', answer)
    answer = re.sub(r'\</i\>', '', answer)
    answer = re.sub(r'\</u\>', '', answer)
    answer = re.sub(r'\<u\>', '', answer)
    answer = re.sub(r'\<em\>', '', answer)
    answer = re.sub(r'\</em\>', '', answer)
    answer = re.sub(r'\s\[.*', '', answer)

    return answer

def hr():
    return st.markdown('<hr>', unsafe_allow_html=True)

